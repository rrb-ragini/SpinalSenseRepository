export default function Head() {
  return (
    <>
      <title>SpinalSense</title>
      <meta name="viewport" content="width=device-width, initial-scale=1" />
    </>
  );
}
